/**
 * Scripts for delete dialog
 */

jQuery(function($) {
    $("#bookly-delete-notify").on('change', function() {
        $('#bookly-delete-reason-cover').toggle();
    })
});