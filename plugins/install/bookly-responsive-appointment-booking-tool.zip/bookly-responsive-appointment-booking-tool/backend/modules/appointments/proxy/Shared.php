<?php
namespace Bookly\Backend\Modules\Appointments\Proxy;

use Bookly\Lib;

/**
 * Class Shared
 * @package Bookly\Backend\Modules\Appointments\Proxy
 *
 * @method static void renderAddOnsComponents() Render components on appointments list page.
 */
abstract class Shared extends Lib\Base\Proxy
{

}