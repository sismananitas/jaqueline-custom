<?php
namespace Bookly\Backend\Modules\Services\Proxy;

use Bookly\Lib;

/**
 * Class Taxes
 * @package Bookly\Backend\Modules\Services\Proxy
 *
 * @method static void renderSubForm( array $service ) Render taxes sub-form.
 */
abstract class Taxes extends Lib\Base\Proxy
{

}