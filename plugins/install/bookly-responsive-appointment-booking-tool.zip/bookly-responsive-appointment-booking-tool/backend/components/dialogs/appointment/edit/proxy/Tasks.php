<?php
namespace Bookly\Backend\Components\Dialogs\Appointment\Edit\Proxy;

use Bookly\Lib;

/**
 * Class RecurringAppointments
 * @package Bookly\Backend\Components\Dialogs\Appointment\Edit\Proxy
 *
 * @method static void renderSkipDate()
 */
abstract class Tasks extends Lib\Base\Proxy
{

}