<?php
/**
 * Plugin support: Bookly - Appointment booking
 *
 * @package WordPress
 * @subpackage ThemeREX Addons
 * @since v1.5
 */

// Don't load directly
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

// Check if plugin is installed and activated
if ( !function_exists( 'trx_utils_exists_bookly' ) ) {
	function trx_utils_exists_bookly() {
		return function_exists('bookly_loader');
	}
}


// One-click import support
//------------------------------------------------------------------------

// Check plugin in the required plugins
if ( !function_exists( 'trx_utils_bookly_importer_required_plugins' ) ) {
	if (is_admin()) add_filter( 'trx_utils_filter_importer_required_plugins',	'trx_utils_bookly_importer_required_plugins', 10, 2 );
	function trx_utils_bookly_importer_required_plugins($not_installed='', $list='') {

		if (strpos($list, 'bookly')!==false && !trx_utils_exists_bookly() )
			$not_installed .= '<br>' . esc_html__('Bookly - Appointment booking', 'trx_utils');
		return $not_installed;
	}
}

// Set plugin's specific importer options
if ( !function_exists( 'trx_utils_bookly_importer_set_options' ) ) {
    if (is_admin()) add_filter( 'trx_utils_filter_importer_options',    'trx_utils_bookly_importer_set_options' );
    function trx_utils_bookly_importer_set_options($options=array()) {
        if ( trx_utils_exists_bookly() && in_array('bookly', $options['required_plugins']) ) {             // Add slugs to export options for this plugin
            $options['additional_options'][]    = 'bookly_%';
            if (is_array($options['files']) && count($options['files']) > 0) {
                foreach ($options['files'] as $k => $v) {
                    $options['files'][$k]['file_with_bookly'] = str_replace('name.ext', 'bookly.txt', $v['file_with_']);
                }
            }
        }
        return $options;
    }
}


// Export posts
if ( !function_exists( 'trx_utils_bookly_importer_export' ) ) {
    if (is_admin()) add_action( 'trx_utils_action_importer_export',    'trx_utils_bookly_importer_export', 10, 1 );
    function trx_utils_bookly_importer_export($importer) {
        if ( trx_utils_exists_bookly() && in_array('bookly', $importer->options['required_plugins']) ) {
            trx_utils_fpc($importer->export_file_dir('bookly.txt'), serialize( array(
                    "bookly_appointments"               => $importer->export_dump("bookly_appointments"),
                    "bookly_categories"                 => $importer->export_dump("bookly_categories"),
                    "bookly_customers"                  => $importer->export_dump("bookly_customers"),
                    "bookly_customer_appointments"      => $importer->export_dump("bookly_customer_appointments"),
                    "bookly_holidays"                   => $importer->export_dump("bookly_holidays"),
                    "bookly_messages"                   => $importer->export_dump("bookly_messages"),
                    "bookly_notifications"              => $importer->export_dump("bookly_notifications"),
                    "bookly_payments"                   => $importer->export_dump("bookly_payments"),
                    "bookly_schedule_item_breaks"       => $importer->export_dump("bookly_schedule_item_breaks"),
                    "bookly_sent_notifications"         => $importer->export_dump("bookly_sent_notifications"),
                    "bookly_series"                     => $importer->export_dump("bookly_series"),
                    "bookly_services"                   => $importer->export_dump("bookly_services"),
                    "bookly_shop"                       => $importer->export_dump("bookly_shop"),
                    "bookly_staff"                      => $importer->export_dump("bookly_staff"),
                    "bookly_staff_schedule_items"       => $importer->export_dump("bookly_staff_schedule_items"),
                    "bookly_staff_services"             => $importer->export_dump("bookly_staff_services"),
                    "bookly_stats"                      => $importer->export_dump("bookly_stats"),
                    "bookly_sub_services"               => $importer->export_dump("bookly_sub_services"),
                ) )
            );
        }
    }
}

// Display exported data in the fields
if ( !function_exists( 'trx_utils_bookly_importer_export_fields' ) ) {
    if (is_admin()) add_action( 'trx_utils_action_importer_export_fields',    'trx_utils_bookly_importer_export_fields', 10, 1 );
    function trx_utils_bookly_importer_export_fields($importer) {
        if ( trx_utils_exists_bookly() && in_array('bookly', $importer->options['required_plugins']) ) {
            $importer->show_exporter_fields(array(
                    'slug'    => 'bookly',
                    'title' => esc_html__('Bookly - Appointment booking', 'trx_utils')
                )
            );
        }
    }
}


// Add checkbox to the one-click importer
if ( !function_exists( 'trx_utils_bookly_importer_show_params' ) ) {
    if (is_admin()) add_action( 'trx_utils_action_importer_params',    'trx_utils_bookly_importer_show_params', 10, 1 );
    function trx_utils_bookly_importer_show_params($importer) {
        if ( trx_utils_exists_bookly() && in_array('bookly', $importer->options['required_plugins']) ) {
            $importer->show_importer_params(array(
                'slug' => 'bookly',
                'title' => esc_html__('Import Bookly', 'trx_utils'),
                'part' => 1
            ));
        }
    }
}


// Display import progress
if ( !function_exists( 'trx_utils_bookly_importer_import_fields' ) ) {
    if (is_admin()) add_action( 'trx_utils_action_importer_import_fields',	'trx_utils_bookly_importer_import_fields', 10, 1 );
    function trx_utils_bookly_importer_import_fields($importer) {
        if ( trx_utils_exists_bookly() && in_array('bookly', $importer->options['required_plugins']) ) {
            $importer->show_importer_fields(array(
                    'slug'=>'bookly',
                    'title' => esc_html__('Bookly meta', 'trx_utils')
                )
            );
        }
    }
}


// Import posts
if ( !function_exists( 'trx_utils_bookly_importer_import' ) ) {
    if (is_admin()) add_action( 'trx_utils_action_importer_import',    'trx_utils_bookly_importer_import', 10, 2 );
    function trx_utils_bookly_importer_import($importer, $action) {
        if ( trx_utils_exists_bookly() && in_array('bookly', $importer->options['required_plugins']) ) {
            if ( $action == 'import_bookly' ) {
                $importer->response['start_from_id'] = 0;
                $importer->import_dump('bookly', esc_html__('Bookly meta', 'trx_utils'));
            }
        }
    }
}






?>