<?php
namespace Bookly\Backend\Components\Dialogs\Staff\Edit\Proxy;

use Bookly\Lib;

/**
 * Class Pro
 *
 * @package Bookly\Backend\Components\Dialogs\Staff\Edit\Proxy
 *
 * @method static string  renderArchivingComponents()
 */
abstract class Pro extends Lib\Base\Proxy
{

}