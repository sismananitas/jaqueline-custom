<?php
namespace Bookly\Lib\Proxy;

use Bookly\Lib;

/**
 * Class Ratings
 * @package Bookly\Lib\Proxy
 *
 * @method static array prepareCaSeSt( array $result ) Add ratings to CaSeSt result.
 */
abstract class Ratings extends Lib\Base\Proxy
{

}