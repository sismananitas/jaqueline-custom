<?php
namespace Bookly\Backend\Components\Dialogs\Appointment\CustomerDetails\Proxy;

use Bookly\Lib;

/**
 * Class Pro
 * @package Bookly\Backend\Components\Dialogs\Appointment
 *
 * @method static void renderTimeZoneSwitcher() Render time zone switcher in Customer Details
 */
abstract class Pro extends Lib\Base\Proxy
{

}