<?php
include '../common.php';

$bookingCategoryObj->updateCategory();
		
	

?>
