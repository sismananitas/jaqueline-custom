<?php
include '../common.php';

$bookingCategoryObj->setDefaultCategory($_GET["category_id"]);

?>